<div class="box-body">
                            <table id="example1" class="table table-bordered">
                                <thead>
                                    <th>Course</th>
                                    <th>Photo</th>
                                    <th>Student ID</th>
                                    <th>Firstname</th>
                                    <th>Lastname</th>
                                    <th>Tools</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $sql = "SELECT *, lms_students.id AS studid FROM lms_students LEFT JOIN lms_course ON lms_course.id=lms_students.course_id";
                                        $query = $conn->query($sql);
                                        while($row = $query->fetch_assoc()){
                                            $photo = (!empty($row['photo'])) ? '../images/'.$row['photo'] : '../images/profile.jpg';
                                            echo "
                                                <tr>
                                                    <td>".$row['code']."</td>
                                                    <td>
                                                        <img src='".$photo."' width='30px' height='30px'>
                                                        <a href='#edit_photo' data-toggle='modal' class='pull-right photo' data-id='".$row['studid']."'><span class='fa fa-edit'></span></a>
                                                    </td>
                                                    <td>".$row['student_id']."</td>
                                                    <td>".$row['firstname']."</td>
                                                    <td>".$row['lastname']."</td>
                                                    <td>
                                                        <button class='btn btn-success btn-sm edit btn-flat' data-id='".$row['studid']."'><i class='fa fa-edit'></i> Edit</button>
                                                        <button class='btn btn-danger btn-sm delete btn-flat' data-id='".$row['studid']."'><i class='fa fa-trash'></i> Delete</button>
                                                    </td>
                                                </tr>
                                            ";
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
<?php include 'includes/scripts.php'; ?>
