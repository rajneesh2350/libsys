<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Open Admin Panel and Add/View user to know Login ID</b>
      </div>
      <strong>&copy; 2021 - IGIPESS&nbsp;Library Management System | By <a href="https://rajneesh2350.github.io/portfolio/">Rajneesh Talwar</a></strong>
      </div>
    <!-- /.container -->
</footer>