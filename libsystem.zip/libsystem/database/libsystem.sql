-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2021 at 07:31 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `libsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `lms_admin`
--

CREATE TABLE `lms_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_admin`
--

INSERT INTO `lms_admin` (`id`, `username`, `password`, `firstname`, `lastname`, `photo`, `created_on`) VALUES
(1, 'Administrator', '$2y$10$cm0HRABhsAVMYXQSRyZfvucMHYO3zR1g4LmKJMlpfD4xu.UxfeKkK', 'Rajneesh', 'Talwar', 'RajneeshTalwar.jpg', '2018-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `lms_books`
--

CREATE TABLE `lms_books` (
  `id` int(11) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `author` varchar(150) NOT NULL,
  `publisher` varchar(150) NOT NULL,
  `publish_date` date NOT NULL,
  `status` int(1) NOT NULL,
  `cost` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_books`
--

INSERT INTO `lms_books` (`id`, `isbn`, `category_id`, `title`, `author`, `publisher`, `publish_date`, `status`, `cost`) VALUES
(4, '0021', 5, 'Effective C++', 'Scott Meyers', 'Hoobstank Publishers', '2018-06-03', 1, '1400.00'),
(5, '01', 1, 'IT Software Engineering', 'Amit Tyagi', 'Jacobs Publisher', '2018-05-07', 1, '150.00'),
(6, '002', 5, 'Python Cookbook', 'ABCDEFF', 'Jacobs Publisher', '2018-06-01', 1, '150.75'),
(7, '005', 1, 'Machinery Handbook', 'ABCDEFF', 'Jacobs Publisher', '2018-04-03', 1, '1000.00'),
(8, '555', 3, 'A Brief History of Time', 'Stephen Hawkings', 'Jacobs Publisher', '2018-06-09', 1, '1200.50'),
(9, '123', 5, 'Java 2', 'Herbert ', 'Demo Publisher', '2018-05-15', 0, '110.50'),
(11, '007', 5, 'Information Technology - Python', 'Sangeeta Gupta', 'IGI', '2021-04-28', 0, '1200.00');

-- --------------------------------------------------------

--
-- Table structure for table `lms_borrow`
--

CREATE TABLE `lms_borrow` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_borrow` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_borrow`
--

INSERT INTO `lms_borrow` (`id`, `student_id`, `book_id`, `date_borrow`, `status`) VALUES
(17, 3, 1, '2018-05-04', 0),
(18, 3, 2, '2018-05-04', 1),
(19, 5, 3, '2018-06-26', 0),
(23, 6, 7, '2018-06-26', 1),
(24, 6, 4, '2018-06-26', 0),
(25, 6, 7, '2021-04-09', 0),
(26, 7, 6, '2021-04-09', 0),
(27, 7, 9, '2021-04-12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lms_category`
--

CREATE TABLE `lms_category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_category`
--

INSERT INTO `lms_category` (`id`, `name`) VALUES
(1, 'Sport Biomechanics'),
(2, 'Fundamentals of Health Education'),
(3, 'Sport Management'),
(4, 'English'),
(5, 'Computer');

-- --------------------------------------------------------

--
-- Table structure for table `lms_course`
--

CREATE TABLE `lms_course` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `code` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_course`
--

INSERT INTO `lms_course` (`id`, `title`, `code`) VALUES
(1, 'Master of Physical Education', 'MPED'),
(2, ' Bachelor of Physical Education', 'BPED'),
(3, 'Bachelor of Science in Physical Education, Health Education & Sports', 'BSC'),
(4, ' Doctor of Philosophy (Ph.D.) in Physical Education ', 'PHD');

-- --------------------------------------------------------

--
-- Table structure for table `lms_returns`
--

CREATE TABLE `lms_returns` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `date_return` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_returns`
--

INSERT INTO `lms_returns` (`id`, `student_id`, `book_id`, `date_return`) VALUES
(3, 3, 2, '2018-05-04'),
(4, 3, 2, '2018-05-04'),
(5, 6, 4, '2018-06-26'),
(6, 6, 7, '2021-04-09'),
(7, 7, 9, '2021-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `lms_students`
--

CREATE TABLE `lms_students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(15) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `course_id` int(11) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_students`
--

INSERT INTO `lms_students` (`id`, `student_id`, `firstname`, `lastname`, `photo`, `course_id`, `created_on`) VALUES
(3, 'IMU702639514', 'Ankur', 'Gola', 'facebook-profile-image.jpeg', 1, '2018-05-04'),
(4, 'TBD917438625', 'Vikas', 'Rana', 'mahatma1.jpg', 2, '2018-05-04'),
(5, 'GSU960812475', 'Rishi', 'Pal', '', 1, '2018-06-26'),
(6, 'NOY017542369', 'Zaved', 'Jr', '', 1, '2018-06-26'),
(7, 'M-021/18', 'Amit', 'Tyagi', '', 4, '2021-04-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lms_admin`
--
ALTER TABLE `lms_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_books`
--
ALTER TABLE `lms_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_borrow`
--
ALTER TABLE `lms_borrow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_category`
--
ALTER TABLE `lms_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_course`
--
ALTER TABLE `lms_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_returns`
--
ALTER TABLE `lms_returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lms_students`
--
ALTER TABLE `lms_students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lms_admin`
--
ALTER TABLE `lms_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lms_books`
--
ALTER TABLE `lms_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lms_borrow`
--
ALTER TABLE `lms_borrow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `lms_category`
--
ALTER TABLE `lms_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lms_course`
--
ALTER TABLE `lms_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lms_returns`
--
ALTER TABLE `lms_returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lms_students`
--
ALTER TABLE `lms_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
