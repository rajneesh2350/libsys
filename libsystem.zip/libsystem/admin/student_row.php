<?php
	include 'includes/session.php';

	if(isset($_POST['id'])){
		$id = $_POST['id'];
		$sql = "SELECT *, lms_students.id AS studid FROM lms_students LEFT JOIN lms_course ON lms_course.id=lms_students.course_id WHERE lms_students.id = '$id'";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		echo json_encode($row);
	}
?>