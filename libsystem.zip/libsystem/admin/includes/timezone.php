<?php
	$timezone = 'Asia/Manila';
	date_default_timezone_set($timezone);
?>