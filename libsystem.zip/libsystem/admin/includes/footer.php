<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2021 - IGIPESS&nbsp;Library Management System | By <a href="https://rajneesh2350.github.io/portfolio/">Rajneesh Talwar</a></strong>
</footer>