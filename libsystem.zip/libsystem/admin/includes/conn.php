<?php
	$conn = new mysqli('localhost', 'c41duigipess', 'MyPassword26November1972', 'c41ducicaci_blitzkreig');

	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	
?>