<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
 <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
                <input class="form-control" id="myInput" type="text" placeholder="Search..">
               <br>

    <table class="table table-bordered">
        <thead>
            <tr>
                 <th>Date</th>
                  <th>Student ID</th>
                  <th>Name</th>
                  <th>ISBN</th>
                  <th>Title</th>
            </tr>
        </thead>
        <tbody id="myTable">

        <?php
                    $sql = "SELECT *, lms_students.student_id AS stud, lms_borrow.status AS barstat FROM lms_borrow LEFT JOIN lms_students ON lms_students.id=lms_borrow.student_id LEFT JOIN lms_books ON lms_books.id=lms_borrow.book_id ORDER BY date_borrow DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
                      if($row['barstat']){
                        $status = '<span class="label label-success">returned</span>';
                      }
                      else{
                        $status = '<span class="label label-danger">not returned</span>';
                      }
                      echo "
                        <tr>
                          <td class='hidden'></td>
                          <td>".date('M d, Y', strtotime($row['date_borrow']))."</td>
                          <td>".$row['stud']."</td>
                          <td>".$row['firstname'].' '.$row['lastname']."</td>
                          <td>".$row['isbn']."</td>
                          <td>".$row['title']."</td>
                        </tr>
                      ";
                    }
                  ?>
        </tbody>
    </table>
</div>
</div></div></div>
<script>
$(document).ready(function(){
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});
</script>
</body>
</html>
