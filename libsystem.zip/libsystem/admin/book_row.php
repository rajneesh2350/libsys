<?php
	include 'includes/session.php';

	if(isset($_POST['id'])){
		$id = $_POST['id'];
		$sql = "SELECT *, lms_books.id AS bookid FROM lms_books LEFT JOIN lms_category ON lms_category.id=lms_books.category_id WHERE lms_books.id = '$id'";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		echo json_encode($row);
	}
?>